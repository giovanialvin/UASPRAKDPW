<?php

class Login extends CI_Controller{

    //konstruktor
    public function __construct()
    {
        parent::__construct();
        $this->load->model('m_login');
    }

    public function index(){
        $this->load->view('login\index');
    }

    public function proses_login(){
        //menampung data dari input form login
        $email = $this->input->post('email');
        $password = $this->input->post('password');

        //mengirimkan data ke model login
        $this->m_login->proses_login($email, $password);
    }

    public function logout(){
        $this->session->sess_destroy();
        redirect('login');
    }

}