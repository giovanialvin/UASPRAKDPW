<?php

class dashboard extends CI_Controller{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('m_dashboard');
    }
    public function index()
    {
        $this->m_security->getSecurity();
        $isi['content'] = 'home';
        $isi['judul']   = 'Dashboard';
        $isi['anggota'] = $this->m_dashboard->countAnggota();
        $isi['buku'] = $this->m_dashboard->countBuku();
        $isi['pinjam'] = $this->m_dashboard->countPinjam();
        $isi['kembali'] = $this->m_dashboard->countKembali();
        $this->load->view('admin_page/dashboard', $isi);
    }
}