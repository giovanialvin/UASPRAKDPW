<?php

class Anggota extends CI_Controller{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('m_anggota');
    }

    public function index(){
        //fungsi untuk menampilkan data
        $isi['content']     = 'data_anggota/index';
        $isi['judul']       = 'Data Anggota';
        $isi['data']        = $this->m_anggota->getAllData();
        $this->load->view('admin_page/dashboard', $isi);
    }

    public function add(){
        //fungsi untuk mengalihkan ke form tambah anggota
        $isi['content']     = 'data_anggota/form';
        $isi['judul']       = 'Data Anggota';
        $isi['id_anggota']  = $this->m_anggota->id_anggota();
        $this->load->view('admin_page/dashboard', $isi);

    }

    public function save()
        //fungsi untuk menambahkan data ke dalam model
    {
        //tampung data
        $data = array(
            'no_reg'        => $this->input->POST('no_reg'),
            'nama'          => $this->input->POST('nama'),
            'jenis_kelamin' => $this->input->POST('jenis_kelamin'),
            'alamat'        => $this->input->POST('alamat'),
            'no_hp'         => $this->input->POST('no_hp'),
            'kuota'         => 5,
            'status'        => 'Aktif'

        );
        $query = $this->m_anggota->addData($data);
        //jika berhasil maka redirect ke halaman data anggota
        if($query = true){
            $this->session->set_flashdata('info', "Data ". $data['nama']. "  berhasil ditambahkan!");
            redirect('anggota');
        }
    }
    public function edit($id)
        //fungsi untuk mengarahkan ke halaman edit dan menampilkan data  
    {
        $isi['content']     = 'data_anggota/edit';
        $isi['judul']       = 'Data Anggota';
        $isi['data']  = $this->m_anggota->getData($id);
        $this->load->view('admin_page/dashboard', $isi);
    }

    public function update()
    {   
        //tampung data
        $id = $this->input->POST('id');
        $data = array(
            'id'            => $this->input->POST('id'),
            'no_reg'        => $this->input->POST('no_reg'),
            'nama'          => $this->input->POST('nama'),
            'jenis_kelamin' => $this->input->POST('jenis_kelamin'),
            'alamat'        => $this->input->POST('alamat'),
            'no_hp'         => $this->input->POST('no_hp')

        );
        $query = $this->m_anggota->updateData($id, $data);
        //jika berhasil maka redirect ke halaman data anggota
        if($query = true){
            $this->session->set_flashdata('info', "Data ". $data['nama']. "  berhasil diperbaharui!");
            redirect('anggota');
        }
    }

    public function delete($id)
    {   
        $data = $this->m_anggota->getData($id);
        $query = $this->m_anggota->deleteData($id);
        if($query = true){
            $this->session->set_flashdata('info', "Data ". $data['nama'] . "  berhasil dihapus!");
            redirect('anggota');
        }
    }


    public function nonaktif($id)
    {   
        //tampung data
        $data = array(
            'status'        => 'Non Aktif'
        );
        $query = $this->m_anggota->updateData($id, $data);
        //jika berhasil maka redirect ke halaman data anggota
        if($query = true){
            $this->session->set_flashdata('info', "Berhasil dinonaktifkan!");
            redirect('anggota');
        }
    }

    public function aktif($id)
    {   
        //tampung data
        $data = array(
            'status'        => 'Aktif'
        );
        $query = $this->m_anggota->updateData($id, $data);
        //jika berhasil maka redirect ke halaman data anggota
        if($query = true){
            $this->session->set_flashdata('info', "Berhasil diaktifkan kembali!");
            redirect('anggota');
        }
    }

}
?>