<?php
class Kategori extends CI_Controller{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('m_kategori');
    }
    public function index()
    {
        $isi['content'] = 'data_kategori/index';
        $isi['judul'] = 'Data Kategori';
        $isi['data'] = $this->m_kategori->getAllData();
        $this->load->view('admin_page/dashboard', $isi);
    }

    public function add()
    {
        $isi['content'] = 'data_kategori/form';
        $isi['judul'] = 'Data Kategori';
        $this->load->view('admin_page/dashboard', $isi);
    }

    public function save()
    {
        $data['nama_kategori'] = $this->input->POST('nama_kategori');
        $query = $this->m_kategori->addData($data);
        if($query = true){
            $this->session->set_flashdata('info', "Data ". $data['nama_kategori']. "  berhasil ditambahkan!");
            redirect('kategori');
        }
    }


    public function edit($id_kategori)
    {
        $isi['content']     = 'data_kategori/edit';
        $isi['judul']       = 'Data Kategori';
        $isi['data']  = $this->m_kategori->getData($id_kategori);
        $this->load->view('admin_page/dashboard', $isi);
    }                                            


    public function update()
    {   
        //tampung data
        $id_kategori = $this->input->POST('id_kategori');
        $data = array(
            'id_kategori'            => $this->input->POST('id_kategori'),
            'nama_kategori'          => $this->input->POST('nama_kategori'),

        );
        $query = $this->m_kategori->updateData($id_kategori, $data);
        //jika berhasil maka redirect ke halaman Data Kategori
        if($query = true){
            $this->session->set_flashdata('info', "Data ". $data['nama_kategori']. "  berhasil diperbaharui!");
            redirect('kategori');
        }
    }


    public function delete($id_kategori)
    {   
        $data = $this->m_kategori->getData($id_kategori);
        $query = $this->m_kategori->deleteData($id_kategori);
        if($query = true){
            $this->session->set_flashdata('info', "Data ". $data['nama_kategori'] . "  berhasil dihapus!");
            redirect('kategori');
        }
    }
}