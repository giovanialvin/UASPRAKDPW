<?php
class Buku extends CI_Controller{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('m_buku');
    }
    public function index(){
        $isi['content']     = 'data_buku/index';
        $isi['judul']       = 'Data Buku';
        $isi['data']        = $this->m_buku->getAllData();
        $this->load->view('admin_page/dashboard', $isi);
    }

    public function add()
    {
        $isi['content']     = 'data_buku/form';
        $isi['judul']       = 'Data Buku';
        $isi['kode_reg']    = $this->m_buku->kode_reg();
        $isi['kategori']   = $this->m_buku->getKategori();
        $isi['pengarang']   = $this->m_buku->getPengarang();
        $isi['penerbit']    = $this->m_buku->getPenerbit();
        // var_dump($isi['penerbit']);
        $this->load->view('admin_page/dashboard', $isi);
    }

    public function save()
    {
        //tampung data
        $data = array(
            'kode_reg'      => $this->input->POST('kode_reg'),
            'judul'         => $this->input->POST('judul'),
            'id_kategori'  => $this->input->POST('id_kategori'),
            'id_pengarang'  => $this->input->POST('id_pengarang'),
            'id_penerbit'   => $this->input->POST('id_penerbit'),
            'tahun'         => $this->input->POST('tahun'),
            'jumlah'        => $this->input->POST('jumlah'),


        );
        $query = $this->m_buku->addData($data);
        //jika berhasil maka redirect ke halaman data buku
        if($query = true){
            $this->session->set_flashdata('info', "Data ". $data['judul']. "  berhasil ditambahkan!");
            redirect('buku');
        }
    }


    public function delete($id_buku)
    {   
        $data = $this->m_buku->getData($id_buku);
        $query = $this->m_buku->deleteData($id_buku);
        if($query = true){
            $this->session->set_flashdata('info', "Data ". $data['nama'] . "  berhasil dihapus!");
            redirect('buku');
        }
    }

    public function edit($id_buku)
    {
        $isi['content']     = 'data_buku/edit';
        $isi['judul']       = 'Data buku';
        // $isi['pengarang']   = $this->db->get('pengarang')->result();
        $isi['kategori']   = $this->m_buku->getKategori();
        $isi['pengarang']   = $this->m_buku->getPengarang();
        $isi['penerbit']    = $this->m_buku->getPenerbit();
        $isi['data']        = $this->m_buku->getData($id_buku);
        $this->load->view('admin_page/dashboard', $isi);
    }

    public function update()
    {   
        $id_buku = $this->input->POST('id_buku');
        //tampung data
        $data = array(
            'id_buku'       => $this->input->POST('id_buku'),
            'kode_reg'      => $this->input->POST('kode_reg'),
            'judul'         => $this->input->POST('judul'),
            'id_kategori '  => $this->input->POST('id_kategori'),
            'id_pengarang'  => $this->input->POST('id_pengarang'),
            'id_penerbit'   => $this->input->POST('id_penerbit'),
            'tahun'         => $this->input->POST('tahun'),
            'jumlah'        => $this->input->POST('jumlah'),


        );
        $query = $this->m_buku->updateData($id_buku ,$data);
        //jika berhasil maka redirect ke halaman data buku
        if($query = true){
            $this->session->set_flashdata('info', "Data ". $data['judul']. "  berhasil diperbaharui!");
            redirect('buku');
        }
    }
}

?>