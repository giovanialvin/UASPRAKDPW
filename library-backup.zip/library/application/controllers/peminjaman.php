<?php

class Peminjaman extends CI_Controller{
    //konstruktor
    public function __construct()
    {
        parent::__construct();
        $this->load->model('m_peminjaman');
    }
    public function index(){
        $isi['content'] = 'data_peminjaman/index';
        $isi['judul']   = 'Data Peminjaman';
        $isi['data']    = $this->m_peminjaman->getAllData();
        $this->load->view('admin_page/dashboard', $isi);
    }

    public function add()
    {
        $isi['content'] = 'data_peminjaman/form';
        $isi['judul']   = 'Data Peminjaman';
        $isi['kode_peminjaman'] = $this->m_peminjaman->getKode_peminjaman();
        $isi['peminjam']        = $this->m_peminjaman->getAnggota();
        $isi['buku']        = $this->m_peminjaman->getBuku();
        $this->load->view('admin_page/dashboard', $isi);
    }

    public function save(){
         //tampung data
         $data = array(
            'kode_peminjaman'       => $this->input->POST('kode_peminjaman'),
            'id_anggota'            => $this->input->POST('id_peminjam'),
            'id_buku'               => $this->input->POST('id_buku'),
            'tanggal_peminjaman'    => $this->input->POST('tanggal_peminjaman'),
            'tanggal_pengembalian'  => $this->input->POST('tanggal_pengembalian'),

        );
        $query = $this->m_peminjaman->addData($data);
        //jika berhasil maka redirect ke halaman data buku
        if($query = true){
            $this->session->set_flashdata('info', "Data ". $data['kode_peminjaman']. "  berhasil ditambahkan!");
            redirect('peminjaman');
        }
    }

    public function kembali($id_peminjaman)
    {
        $data = $this->m_peminjaman->getData($id_peminjaman);
        $kembalikan = array
        (
            'id_anggota'                => $data['id_anggota'],
            'id_buku'                   => $data['id_buku'],
            'id_peminjaman'             => $data['id_peminjaman'],
            'tanggal_peminjaman'        => $data['tanggal_peminjaman'],
            'tanggal_pengembalian'      => $data['tanggal_pengembalian'],
            'tanggal_pengembalian_real' => date('Y-m-d'),
        );

        $query = $this->m_peminjaman->pengembalianBuku($kembalikan);
        //jika berhasil maka redirect ke halaman data buku
        if($query = true){
            $delete = $this->m_peminjaman->delete($id_peminjaman);
            if($delete = true){
                $this->session->set_flashdata('info', "Buku". $data['judul']. "  berhasil dikembalikan!");
                redirect('peminjaman/index');
            }
        }
    }
}   