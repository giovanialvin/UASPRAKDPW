<?php

class Pengembalian extends CI_Controller{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('m_pengembalian');
    }
    public function index(){
        $isi['content'] = 'data_pengembalian/index';
        $isi['judul'] = 'Data Pengembalian';
        $isi['data'] = $this->m_pengembalian->getAllData();
        // var_dump($isi['data']);
        $this->load->view('admin_page/dashboard', $isi);
    }
}