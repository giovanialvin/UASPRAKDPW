<?php
class Pengarang extends CI_Controller{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('m_pengarang');
    }
    public function index()
    {
        $isi['content'] = 'data_pengarang/index';
        $isi['judul'] = 'Data Pengarang';
        $isi['data'] = $this->m_pengarang->getAllData();
        $this->load->view('admin_page/dashboard', $isi);
    }

    public function add()
    {
        $isi['content'] = 'data_pengarang/form';
        $isi['judul'] = 'Data Pengarang';
        $this->load->view('admin_page/dashboard', $isi);
    }

    public function save()
    {
        $data['nama_pengarang'] = $this->input->POST('nama_pengarang');
        $query = $this->m_pengarang->addData($data);
        if($query = true){
            $this->session->set_flashdata('info', "Data ". $data['nama_pengarang']. "  berhasil ditambahkan!");
            redirect('pengarang');
        }
    }


    public function edit($id_pengarang)
    {
        $isi['content']     = 'data_pengarang/edit';
        $isi['judul']       = 'Data Pengarang';
        $isi['data']  = $this->m_pengarang->getData($id_pengarang);
        $this->load->view('admin_page/dashboard', $isi);
    }                                            


    public function update()
    {   
        //tampung data
        $id_pengarang = $this->input->POST('id_pengarang');
        $data = array(
            'id_pengarang'            => $this->input->POST('id_pengarang'),
            'nama_pengarang'          => $this->input->POST('nama_pengarang'),

        );
        $query = $this->m_pengarang->updateData($id_pengarang, $data);
        //jika berhasil maka redirect ke halaman data pengarang
        if($query = true){
            $this->session->set_flashdata('info', "Data ". $data['nama_pengarang']. "  berhasil diperbaharui!");
            redirect('pengarang');
        }
    }


    public function delete($id_pengarang)
    {   
        $data = $this->m_pengarang->getData($id_pengarang);
        $query = $this->m_pengarang->deleteData($id_pengarang);
        if($query = true){
            $this->session->set_flashdata('info', "Data ". $data['nama_pengarang'] . "  berhasil dihapus!");
            redirect('pengarang');
        }
    }
}