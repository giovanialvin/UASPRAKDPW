<?php
class Penerbit extends CI_Controller{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('m_penerbit');
    }
    public function index()
    {
        $isi['content'] = 'data_penerbit/index';
        $isi['judul'] = 'Data Penerbit';
        $isi['data'] = $this->m_penerbit->getAllData();
        $this->load->view('admin_page/dashboard', $isi);
    }

    public function add()
    {
        $isi['content'] = 'data_penerbit/form';
        $isi['judul'] = 'Data Penerbit';
        $this->load->view('admin_page/dashboard', $isi);
    }

    public function save()
    {
        $data['nama_penerbit'] = $this->input->POST('nama_penerbit');
        $query = $this->m_penerbit->addData($data);
        if($query = true){
            $this->session->set_flashdata('info', "Data ". $data['nama_penerbit']. "  berhasil ditambahkan!");
            redirect('penerbit');
        }
    }


    public function edit($id_penerbit)
    {
        $isi['content']     = 'data_penerbit/edit';
        $isi['judul']       = 'Data Penerbit';
        $isi['data']  = $this->m_penerbit->getData($id_penerbit);
        $this->load->view('admin_page/dashboard', $isi);
    }                                            


    public function update()
    {   
        //tampung data
        $id_penerbit = $this->input->POST('id_penerbit');
        $data = array(
            'id_penerbit'            => $this->input->POST('id_penerbit'),
            'nama_penerbit'          => $this->input->POST('nama_penerbit'),

        );
        $query = $this->m_penerbit->updateData($id_penerbit, $data);
        //jika berhasil maka redirect ke halaman Data Penerbit
        if($query = true){
            $this->session->set_flashdata('info', "Data ". $data['nama_penerbit']. "  berhasil diperbaharui!");
            redirect('penerbit');
        }
    }


    public function delete($id_penerbit)
    {   
        $data = $this->m_penerbit->getData($id_penerbit);
        $query = $this->m_penerbit->deleteData($id_penerbit);
        if($query = true){
            $this->session->set_flashdata('info', "Data ". $data['nama_penerbit'] . "  berhasil dihapus!");
            redirect('penerbit');
        }
    }
}