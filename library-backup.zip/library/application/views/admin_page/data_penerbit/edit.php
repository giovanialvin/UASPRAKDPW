<!-- Horizontal Form -->
<div class="box box-info">
    <div class="box-header with-border">
        <h3 class="box-title">Tambah Data Penerbit</h3>
    </div>
    <!-- /.box-header -->
    <!-- form start -->
    <form method="POST" action="<?= base_url() ?>penerbit/update" class="form-horizontal">
        <div class="box-body">


            <div class="form-group">
                <div class="col-sm-10">
                    <input type="hidden" name="id_penerbit" class="form-control" value="<?= $data['id_penerbit']; ?>">
                </div>
            </div>

            <div class="form-group">
                <label for="inputnama_penerbit3" class="col-sm-2 control-label">Nama Penerbit</label>

                <div class="col-sm-10">
                    <input type="text" name="nama_penerbit" class="form-control" id="inputnama_penerbit3" value="<?= $data['nama_penerbit']; ?>" required>
                </div>
            </div>

        </div>
        <!-- /.box-body -->
        <div class="box-footer">
            <a href="<?= base_url() ?>penerbit" class="btn btn-warning">Cancel</a>
            <button type="submit" class="btn btn-info pull-right">Update</button>
        </div>
        <!-- /.box-footer -->
    </form>
</div>
<!-- /.box -->