
<!-- Horizontal Form -->
<div class="box box-info">
    <div class="box-header with-border">
        <h3 class="box-title">Tambah Data Penerbit</h3>
    </div>
    <!-- /.box-header -->
    <!-- form start -->
    <form method="POST" action="<?= base_url()?>penerbit/save" class="form-horizontal">
        <div class="box-body">


            <div class="form-group">
                <label for="inputnama_penerbit3" class="col-sm-2 control-label">Nama Penerbit</label>

                <div class="col-sm-10">
                    <input type="text" name="nama_penerbit" class="form-control" id="inputnama_penerbit3" placeholder="Nama Penerbit" required>
                </div>
            </div>


        </div>
        <!-- /.box-body -->
        <div class="box-footer">
            <a href="<?= base_url()?>penerbit" class="btn btn-warning">Cancel</a>
            <button type="submit" class="btn btn-info pull-right">Submit</button>
        </div>
        <!-- /.box-footer -->
    </form>
</div>
<!-- /.box -->