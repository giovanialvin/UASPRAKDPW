<?php

if (!empty($this->session->flashdata('info'))) { ?>
    <div class="alert alert-success" role="alert"><?= $this->session->flashdata('info'); ?></div>
<?php
}




?>

<div class="row">
    <div class="col-md-12">
        <a href="<?= base_url() ?>peminjaman/add" class="btn btn-success"> <i class="fa fa-plus"> </i>&nbsp; Add</a>

    </div>
</div>

<br>

<div class="box">
    <div class="box-header">
    </div>
    <!-- /.box-header -->
    <div class="box-body">
        <table id="example1" class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Kode Peminjaman</th>
                    <th>Peminjamn</th>
                    <th>Buku</th>
                    <th>Tanggal Peminjaman</th>
                    <th>Tanggal Pengembalian</th>
                    <th>Status</th>
                    <th>Aksi</th>

                </tr>
            </thead>
            <tbody>
            <?php
                $no = 1;
                foreach ($data->result() as $row) { 
                    $tgl_kmbl = new DateTime($row->tanggal_pengembalian);
                    $tgl_skrg = new DateTime();
                    $selisih = $tgl_skrg->diff($tgl_kmbl)->format("%a");
                    ?>
                    <tr>
                        <td> <?= $no; ?> </td>
                        <td> <?= $row->kode_peminjaman; ?> </td>
                        <td> <?= $row->nama; ?> </td>
                        <td> <?= $row->judul; ?> </td>
                        <td> <?= $row->tanggal_peminjaman; ?> </td>
                        <td> <?= $row->tanggal_pengembalian; ?> </td>
                        <td> <?php
                                if($tgl_kmbl >= $tgl_skrg OR $selisih == 0){
                                    echo "<span class = 'label label-warning'>Belum Dikembalikan</span>";
                                }else{
                                    $denda = $selisih * 1000;
                                    echo "Terlambat <b style = 'color:red'>".$selisih."</b> Hari <br><span class='label label-danger'>Denda = Rp.". $denda .",- </span>";
                                }

                            ?> 
                        </td>
                        <td>
                            <a href="<?= base_url() ?>peminjaman/kembali/<?= $row->id_peminjaman; ?>" class="btn btn-primary btn-xs" onclick="return confirm('Buku <?= $row->judul; ?> akan dikembalikan')">Kembali</a>
                            <!-- <a href="<?= base_url() ?>peminjaman/edit/<?= $row->id_peminjaman; ?>" class="btn btn-success btn-xs">Edit</a>
                            <a href="<?= base_url() ?>peminjaman/delete/<?= $row->id_peminjaman; ?>" class="btn btn-danger btn-xs" onclick="return confirm('Data <?= $row->judul; ?> akan dihapus');">Delete</a> -->
                        </td>
                    </tr>
                <?php
                    $no++;
                }

                ?>


            </tbody>
        </table>
    </div>
    <!-- /.box-body -->
</div>