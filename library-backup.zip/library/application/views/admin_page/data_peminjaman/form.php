<?php
    $tgl_pnjm = date('Y-m-d');
    $seminggu = mktime(0,0,0,date("n"),date("j") + 7, date("Y"));
    $tgl_kmbl = date('Y-m-d', $seminggu);
?>
<!-- Horizontal Form -->
<div class="box box-info">
    <div class="box-header with-border">
        <h3 class="box-title">Tambah Data Peminjaman</h3>
    </div>
    <!-- /.box-header -->
    <!-- form start -->
    <form method="POST" action="<?= base_url()?>peminjaman/save" class="form-horizontal">
        <div class="box-body">


            <div class="form-group">
                <label for="inputkode_peminjaman3" class="col-sm-2 control-label">Kode Peminjaman</label>

                <div class="col-sm-10">
                    <input type="text" name="kode_peminjaman" class="form-control" id="inputkode_peminjaman3" value="<?= $kode_peminjaman?>" readonly>
                </div>
            </div>

            <div class="form-group">
                <label class="col-sm-2 control-label">Peminjam</label>

                <div class="col-sm-10">
                    <select name="id_peminjam" class="form-control select2" required>
                        <option value="">- Pilih Peminjam -</option>
                        <?php
                            foreach ($peminjam as $row){
                                if($row->kuota > 0  && $row->status == 'Aktif'){
                                ?>
                                <option value="<?= $row->id?>"><?= $row->no_reg?>  - <?= $row->nama?></option>
                            <?php 
                            }
                            }
                        ?>
                    </select>
                </div>
            </div>


            <div class="form-group">
                <label class="col-sm-2 control-label">Buku</label>

                <div class="col-sm-10">
                    <select name="id_buku" id="id_buku" class="form-control select2" required>
                        <option value="">- Pilih buku -</option>
                        <?php
                            foreach ($buku as $row){
                                if($row->jumlah > 0){?>
                                <option value="<?= $row->id_buku?>"><?= $row->judul?></option>
                            <?php
                                }
                            }
                        ?>
                    </select>
                </div>
            </div>



            <div class="form-group">
                <label for="inputtanggal_peminjaman3" class="col-sm-2 control-label">Tanggal Peminjaman</label>

                <div class="col-sm-10">
                    <input type="date" name="tanggal_peminjaman" class="form-control" id="inputtanggal_peminjaman3" placeholder="tanggal_peminjaman" value="<?= $tgl_pnjm?>" readonly>
                </div>
            </div>


            <div class="form-group">
                <label for="inputtanggal_pengembalian3" class="col-sm-2 control-label">Tanggal Pengembalian</label>

                <div class="col-sm-10">
                    <input type="date" name="tanggal_pengembalian" class="form-control" id="inputtanggal_pengembalian3" placeholder="tanggal_pengembalian" value="<?= $tgl_kmbl?>" readonly>
                </div>
            </div>


        </div>
        <!-- /.box-body -->
        <div class="box-footer">
            <a href="<?= base_url()?>peminjaman" class="btn btn-warning">Cancel</a>
            <button type="submit" class="btn btn-info pull-right">Submit</button>
        </div>
        <!-- /.box-footer -->
    </form>
</div>
<!-- /.box -->

