<!-- Horizontal Form -->
<div class="box box-info">
    <div class="box-header with-border">
        <h3 class="box-title">Tambah Data Kategori</h3>
    </div>
    <!-- /.box-header -->
    <!-- form start -->
    <form method="POST" action="<?= base_url() ?>kategori/update" class="form-horizontal">
        <div class="box-body">


            <div class="form-group">
                <div class="col-sm-10">
                    <input type="hidden" name="id_kategori" class="form-control" value="<?= $data['id_kategori']; ?>">
                </div>
            </div>

            <div class="form-group">
                <label for="inputnama_kategori3" class="col-sm-2 control-label">Nama Kategori</label>

                <div class="col-sm-10">
                    <input type="text" name="nama_kategori" class="form-control" id="inputnama_kategori3" value="<?= $data['nama_kategori']; ?>" required>
                </div>
            </div>

        </div>
        <!-- /.box-body -->
        <div class="box-footer">
            <a href="<?= base_url() ?>kategori" class="btn btn-warning">Cancel</a>
            <button type="submit" class="btn btn-info pull-right">Update</button>
        </div>
        <!-- /.box-footer -->
    </form>
</div>
<!-- /.box -->