<?php

if (!empty($this->session->flashdata('info'))) { ?>
    <div class="alert alert-success" role="alert"><?= $this->session->flashdata('info'); ?></div>
<?php
}




?>

<div class="row">
    <div class="col-md-12">
        <a href="<?= base_url() ?>buku/add" class="btn btn-success"> <i class="fa fa-plus"> </i>&nbsp; Add</a>

    </div>
</div>

<br>

<div class="box">
    <div class="box-header">
    </div>
    <!-- /.box-header -->
    <div class="box-body">
        <table id="example1" class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Kode Registrasi</th>
                    <th>Judul</th>
                    <th>Kategori</th>
                    <th>Pengarang</th>
                    <th>Penerbit</th>
                    <th>Tahun Terbit</th>
                    <th>Jumlah</th>
                    <th>Aksi</th>

                </tr>
            </thead>
            <tbody>
                <?php
                $no = 1;
                foreach ($data->result() as $row) { ?>
                    <tr>
                        <td> <?= $no; ?> </td>
                        <td> <?= $row->kode_reg; ?> </td>
                        <td> <?= $row->judul; ?> </td>
                        <td> <?= $row->nama_kategori; ?> </td>
                        <td> <?= $row->nama_pengarang; ?> </td>
                        <td> <?= $row->nama_penerbit; ?> </td>
                        <td> <?= $row->tahun; ?> </td>
                        <td> <?= $row->jumlah; ?> </td>
                        <td>
                            <a href="<?= base_url() ?>buku/edit/<?= $row->id_buku; ?>" class="btn btn-success btn-xs">Edit</a>
                            <a href="<?= base_url() ?>buku/delete/<?= $row->id_buku; ?>" class="btn btn-danger btn-xs" onclick="return confirm('Data <?= $row->judul; ?> akan dihapus');">Delete</a>
                        </td>
                    </tr>
                <?php
                    $no++;
                }

                ?>


            </tbody>
        </table>
    </div>
    <!-- /.box-body -->
</div>