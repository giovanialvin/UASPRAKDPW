<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style type="text/css">
        .tgl_akhir{
            margin-left: -20px;
        }

        .btn_filter{
            margin-left: -40px;
        }

        .btn_refresh{
            margin-left: -60px;
        }

        .btn_pdf{
            margin-left: -80px;
        }
    </style>
</head>

<body>
    <div class="box">
        <div class="box-header">
            <form action="<?= base_url()?>laporan/index" method="POST">
                <div class="row">
                    <div class="col-md-3">
                        <h4 class="text-primary">
                            <b>
                            Filter Laporan Peminjaman
                            </b>
                        </h4>
                    </div>

                    <div class="col-md-2">
                       <input type="text" name="tanggal_awal" class="form-control" placeholder="Tanggal Awal" onfocus="(this.type='date')">
                    </div>

                    <div class="col-md-2">
                       <input type="text" name="tanggal_akhir" class="form-control tgl_akhir" placeholder="Tanggal Akhir" onfocus="(this.type='date')">
                    </div>

                    <div class="col-md-1">
                       <button type="submit" class="btn btn-primary btn-block btn_filter"> <i class="fa fa-filter"></i> Filter </button>
                    </div>

                    <div class="col-md-2">
                       <a href="<?= base_url()?>laporan/refresh" class="btn btn-warning btn-block btn_refresh" > <i class="fa fa-refresh"></i> Refresh</a>
                    </div>

                </div>
            </form>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
            <table id="example1" class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Kode Peminjaman</th>
                        <th>Peminjamn</th>
                        <th>Buku</th>
                        <th>Tanggal Peminjaman</th>
                        <th>Tanggal Pengembalian</th>

                    </tr>
                </thead>
                <tbody>
                <?php
                $no = 1;
                foreach ($data->result() as $row) { 
                    ?>
                    <tr>
                        <td> <?= $no; ?> </td>
                        <td> <?= $row->kode_peminjaman; ?> </td>
                        <td> <?= $row->nama; ?> </td>
                        <td> <?= $row->judul; ?> </td>
                        <td> <?= mediumdate_indo($row->tanggal_peminjaman); ?> </td>
                        <td> <?=  mediumdate_indo($row->tanggal_pengembalian); ?> </td>
                        
                    </tr>
                <?php
                    $no++;
                }

                ?>

                </tbody>
            </table>
        </div>
        <!-- /.box-body -->
    </div>
</body>

</html>
<br>