<!-- Horizontal Form -->
<div class="box box-info">
    <div class="box-header with-border">
        <h3 class="box-title">Tambah Data Anggota</h3>
    </div>
    <!-- /.box-header -->
    <!-- form start -->
    <form method="POST" action="<?= base_url() ?>anggota/update" class="form-horizontal">
        <div class="box-body">


            <div class="form-group">
                <div class="col-sm-10">
                    <input type="hidden" name="id" class="form-control" value="<?= $data['id']; ?>">
                </div>
            </div>
            <div class="form-group">
                <label for="inputno_reg3" class="col-sm-2 control-label">Nomor Registrasi</label>

                <div class="col-sm-10">
                    <input type="text" name="no_reg" class="form-control" value="<?= $data['no_reg']; ?>" readonly>
                </div>
            </div>

            <div class="form-group">
                <label for="inputnama3" class="col-sm-2 control-label">Nama</label>

                <div class="col-sm-10">
                    <input type="text" name="nama" class="form-control" id="inputnama3" value="<?= $data['nama']; ?>" required>
                </div>
            </div>


            <div class="form-group">
                <label class="col-sm-2 control-label">Jenis Kelamin</label>
                <div class="col-sm-10">
                    <select name="jenis_kelamin" class="form-control" required>
                        <option value=""> - Pilih Jenis Kelamin - </option>
                        <?php
                        if ($data['jenis_kelamin'] == 'Perempuan') { ?>
                            <option value="Laki-Laki">Laki-Laki</option>
                            <option value="Perempuan" selected>Perempuan</option>

                        <?php
                        } else { ?>
                            <option value="Laki-Laki" selected>Laki-Laki</option>
                            <option value="Perempuan">Perempuan</option>
                        <?php
                        }
                        ?>

                    </select>
                </div>
            </div>


            <div class="form-group">
                <label for="inputalamat3" class="col-sm-2 control-label">Alamat</label>

                <div class="col-sm-10">
                    <textarea type="text" name="alamat" class="form-control" id="inputalamat3" cols="30" rows="5" required><?= $data['alamat']; ?></textarea>
                </div>
            </div>

            <div class="form-group">
                <label for="inputno_hp3" class="col-sm-2 control-label">Nomor Handphone</label>

                <div class="col-sm-10">
                    <input type="text" name="no_hp" class="form-control" id="inputno_hp3" value="<?= $data['no_hp']; ?>" required>
                </div>
            </div>

        </div>
        <!-- /.box-body -->
        <div class="box-footer">
            <a href="<?= base_url() ?>anggota" class="btn btn-warning">Cancel</a>
            <button type="submit" class="btn btn-info pull-right">Update</button>
        </div>
        <!-- /.box-footer -->
    </form>
</div>
<!-- /.box -->