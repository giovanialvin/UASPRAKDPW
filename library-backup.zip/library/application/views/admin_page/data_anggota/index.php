<?php

if (!empty($this->session->flashdata('info'))) { ?>
    <div class="alert alert-success" role="alert"><?= $this->session->flashdata('info'); ?></div>
<?php
}

?>

<div class="row">
    <div class="col-md-12">
        <a href="<?= base_url() ?>anggota/add" class="btn btn-success"> <i class="fa fa-plus"> </i>&nbsp; Add</a>

    </div>
</div>

<br>

<div class="box">
    <div class="box-header">
        <h3 class="box-title">Data Anggota Aktif</h3>
    </div>
    <!-- /.box-header -->
    <div class="box-body">
        <table id="example1" class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nomer Registrasi</th>
                    <th>Nama Anggota</th>
                    <th>Jenis Kelamin</th>
                    <th>Alamat</th>
                    <th>No. Telpon</th>
                    <th>Kuota Peminjaman</th>
                    <th>Aksi</th>

                </tr>
            </thead>
            <tbody>
                <?php
                $no = 1;
                foreach ($data as $row) {
                    if ($row->status == 'Aktif') {
                ?>
                        <tr>
                            <td> <?= $no; ?> </td>
                            <td> <?= $row->no_reg; ?> </td>
                            <td> <?= $row->nama; ?> </td>
                            <td> <?= $row->jenis_kelamin; ?> </td>
                            <td> <?= $row->alamat; ?> </td>
                            <td> <?= $row->no_hp; ?> </td>
                            <td> <?= $row->kuota; ?>/5 </td>
                            <td>
                                <a href="<?= base_url() ?>anggota/edit/<?= $row->id; ?>" class="btn btn-success btn-xs">Edit</a>
                                <a href="<?= base_url() ?>anggota/nonaktif/<?= $row->id; ?>" class="btn btn-danger btn-xs" onclick="return confirm('<?= $row->nama; ?> akan dinonaktifkan');">Non Aktifkan</a>
                            </td>
                        </tr>
                <?php
                        $no++;
                    }
                }

                ?>
            </tbody>
        </table>
    </div>
    <!-- /.box-body -->
</div>


<div class="box">
    <div class="box-header">
        <h3 class="box-title">Data Anggota Non Aktif</h3>
    </div>
    <!-- /.box-header -->
    <div class="box-body">
        <table id="example1" class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nomer Registrasi</th>
                    <th>Nama Anggota</th>
                    <th>Jenis Kelamin</th>
                    <th>Alamat</th>
                    <th>No. Telpon</th>
                    <th>Aksi</th>

                </tr>
            </thead>
            <tbody>
                <?php
                $no = 1;
                foreach ($data as $row) {
                    if ($row->status != 'Aktif') {
                ?>
                        <tr>
                            <td> <?= $no; ?> </td>
                            <td> <?= $row->no_reg; ?> </td>
                            <td> <?= $row->nama; ?> </td>
                            <td> <?= $row->jenis_kelamin; ?> </td>
                            <td> <?= $row->alamat; ?> </td>
                            <td> <?= $row->no_hp; ?> </td>
                            <td>
                                <a href="<?= base_url() ?>anggota/aktif/<?= $row->id; ?>" class="btn btn-danger btn-xs" onclick="return confirm('<?= $row->nama; ?> akan diaktifkan kembali');">Aktifkan</a>
                            </td>
                        </tr>
                <?php
                        $no++;
                    }
                }

                ?>
            </tbody>
        </table>
    </div>
    <!-- /.box-body -->
</div>



<div class="box">
    <div class="box-header">
        <h3 class="box-title">Data Seluruh Anggota</h3>
    </div>
    <!-- /.box-header -->
    <div class="box-body">
        <table id="example1" class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nomer Registrasi</th>
                    <th>Nama Anggota</th>
                    <th>Jenis Kelamin</th>
                    <th>Alamat</th>
                    <th>No. Telpon</th>
                    <th>Status</th>

                </tr>
            </thead>
            <tbody>
                <?php
                $no = 1;
                foreach ($data as $row) {

                ?>
                    <tr>
                        <td> <?= $no; ?> </td>
                        <td> <?= $row->no_reg; ?> </td>
                        <td> <?= $row->nama; ?> </td>
                        <td> <?= $row->jenis_kelamin; ?> </td>
                        <td> <?= $row->alamat; ?> </td>
                        <td> <?= $row->no_hp; ?> </td>
                        <td> <?= $row->status; ?> </td>

                    </tr>
                <?php
                    $no++;
                }

                ?>
            </tbody>
        </table>
    </div>
    <!-- /.box-body -->
</div>