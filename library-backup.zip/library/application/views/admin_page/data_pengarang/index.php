<?php

if (!empty($this->session->flashdata('info'))) { ?>
    <div class="alert alert-success" role="alert"><?= $this->session->flashdata('info'); ?></div>
<?php
}




?>

<div class="row">
    <div class="col-md-12">
        <a href="<?= base_url() ?>pengarang/add" class="btn btn-success"> <i class="fa fa-plus"> </i>&nbsp; Add</a>

    </div>
</div>

<br>

<div class="box">
    <div class="box-header">
    </div>
    <!-- /.box-header -->
    <div class="box-body">
        <table id="example1" class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Pengarang</th>
                    <th>Aksi</th>
                    
                </tr>
            </thead>
            <tbody>
            
                <?php
                $no = 1;
                foreach ($data as $row) { ?>
                    <tr>
                        <td> <?= $no; ?> </td>
                        <td> <?= $row->nama_pengarang; ?> </td>
                        <td>
                            <a href="<?= base_url() ?>pengarang/edit/<?= $row->id_pengarang; ?>" class="btn btn-success btn-xs">Edit</a>
                            <a href="<?= base_url() ?>pengarang/delete/<?= $row->id_pengarang; ?>" class="btn btn-danger btn-xs" onclick="return confirm('Data <?= $row->nama_pengarang; ?> akan dihapus');">Delete</a>
                        </td>
                    </tr>
                <?php
                    $no++;
                }

                ?>
            
            </tbody>
        </table>
    </div>
    <!-- /.box-body -->
</div>