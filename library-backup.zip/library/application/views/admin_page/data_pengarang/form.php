
<!-- Horizontal Form -->
<div class="box box-info">
    <div class="box-header with-border">
        <h3 class="box-title">Tambah Data Pengarang</h3>
    </div>
    <!-- /.box-header -->
    <!-- form start -->
    <form method="POST" action="<?= base_url()?>pengarang/save" class="form-horizontal">
        <div class="box-body">


            <div class="form-group">
                <label for="inputnama_pengarang3" class="col-sm-2 control-label">Nama Pengarang</label>

                <div class="col-sm-10">
                    <input type="text" name="nama_pengarang" class="form-control" id="inputnama_pengarang3" placeholder="Nama Pengarang" required>
                </div>
            </div>


        </div>
        <!-- /.box-body -->
        <div class="box-footer">
            <a href="<?= base_url()?>pengarang" class="btn btn-warning">Cancel</a>
            <button type="submit" class="btn btn-info pull-right">Submit</button>
        </div>
        <!-- /.box-footer -->
    </form>
</div>
<!-- /.box -->