<?php

class M_security extends CI_Model{
    public function getSecurity(){
        //nampung email user
        $email = $this->session->userdata('email');
        //jika tidak terdapat email user
        if(empty($email)){
            //hapus session dan redirect ke halaman login
            $this->session->sess_destroy();
            redirect('login');
        }
    }
}