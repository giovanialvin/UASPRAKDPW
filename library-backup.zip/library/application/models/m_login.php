<?php

class M_login extends CI_Model{
    public function proses_login($email, $password)
    {
        //enkirpsi password dengan md5
        $password = md5($password);

        //pengecekan dengan database
        $email = $this->db->where('email', $email);
        $password = $this->db->where('password', $password);
        
        $query = $this->db->get('login');
        //jika terdapat hasil dari pengecekan, makan tampung data user ke dalam array assosiatif
        if($query->num_rows() > 0){
            foreach($query->result() as $res){
                $sess = array(
                    'id'        => $res->id,
                    'nama'      => $res->nama,
                    'email'     => $res->email,
                    'password'  => $res->password,
                    'level'     => $res->level,
                );
                //set session sesuai data user
                $this->session->set_userdata($sess);
            }
            //redirect ke halaman dashboard
            redirect('dashboard');
        }else{
            //jika gagal kirim message error di dalam halaman login
            $this->session->set_flashdata('info', '<div class="alert alert-danger" role="alert">Login Failed! Email or Password incorrect!</div>');
            redirect('login');
        }
    }
}