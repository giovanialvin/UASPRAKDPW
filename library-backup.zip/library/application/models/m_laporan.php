<?php
class M_laporan extends CI_Model{
    public function getAllData()
    {
        $this->db->select('*');
        $this->db->from('peminjaman');
        $this->db->join('anggota', 'peminjaman.id_anggota = anggota.id');
        $this->db->join('buku', 'peminjaman.id_buku = buku.id_buku');
        return $this->db->get();
    }


    public function filterData($tgl_awal, $tgl_akhir)
    {
        $this->db->select('*');
        $this->db->from('peminjaman');
        $this->db->join('anggota', 'peminjaman.id_anggota = anggota.id');
        $this->db->join('buku', 'peminjaman.id_buku = buku.id_buku');
        $this->db->where('peminjaman.tanggal_peminjaman >=', $tgl_awal);
        $this->db->where('peminjaman.tanggal_peminjaman <=', $tgl_akhir);
        return $this->db->get();
    }
}

?>