<?php

class m_anggota extends CI_Model{
    public function id_anggota(){
        //ambil 3 karakter  id sebelah kanan  dari database sebagai kode
        $this->db->select('RIGHT(no_reg,3) as kode', FALSE);
        //urutkan menurut id secara menurun
        $this->db->order_by('no_reg', 'DESC');
        //ambil 1 record saja
        $this->db->limit(1);
        //sebutkan nama tabel
        $query = $this->db->get('anggota');

        /*
        SELECT * FROM anggota as kode ORDER BY id LIMIT 1
        */

        //jika terdapat record pada variabel query
        if($query->num_rows() > 0){
            //tampung record tersebut
            $data = $query->row();
            //masukan ke variabel dan ditambah 1
            $kode = intval($data->kode)+1;
        }else{
            //jika tidak ada record pada tabel anggota, maka kode bernilai 1
            $kode = 1;
        }
        //gabungkan kode 
        $kodemax = str_pad($kode, 3, "0", STR_PAD_LEFT);
        $finalkode = "AG".$kodemax;

        //kembalikan kode final
        return $finalkode;
    }


    public function addData($data){
        //masukkan data sesuai inputan pada form
        $this->db->insert('anggota', $data);
    }

    public function getAllData(){
        return $this->db->get('anggota')->result();
    }

    public function getData($id)
    {
        $this->db->where('id', $id);
        return $this->db->get('anggota')->row_array();
    }

    public function updateData($id, $data)
    {
        $this->db->where('id', $id);
        $this->db->update('anggota', $data);
    }

    public function deleteData($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('anggota');

    }
}