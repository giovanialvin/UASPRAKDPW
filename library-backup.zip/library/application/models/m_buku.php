<?php

class m_buku extends CI_Model{
    public function kode_reg(){
        //ambil 3 karakter  id sebelah kanan  dari database sebagai kode
        $this->db->select('RIGHT(kode_reg,3) as kode', FALSE);
        //urutkan menurut id secara menurun
        $this->db->order_by('kode_reg', 'DESC');
        //ambil 1 record saja
        $this->db->limit(1);
        //sebutkan nama tabel
        $query = $this->db->get('buku');

        /*
        SELECT * FROM buku as kode ORDER BY id LIMIT 1
        */

        //jika terdapat record pada variabel query
        if($query->num_rows() > 0){
            //tampung record tersebut
            $data = $query->row();
            //masukan ke variabel dan ditambah 1
            $kode = intval($data->kode)+1;
        }else{
            //jika tidak ada record pada tabel buku, maka kode bernilai 1
            $kode = 1;
        }
        //gabungkan kode 
        $kodemax = str_pad($kode, 3, "0", STR_PAD_LEFT);
        $finalkode = "BK".$kodemax;

        //kembalikan kode final
        return $finalkode;
    }


    public function addData($data){
        //masukkan data sesuai inputan pada form
        $this->db->insert('buku', $data);
    }

    public function getAllData(){
        $this->db->select('*');
        $this->db->from('buku');
        $this->db->join('kategori', 'buku.id_kategori = kategori.id_kategori');
        $this->db->join('pengarang', 'buku.id_pengarang = pengarang.id_pengarang');
        $this->db->join('penerbit', 'buku.id_penerbit = penerbit.id_penerbit');
        return $this->db->get();
        // return $this->db->get('buku')->result();
    }

    public function getData($id_buku)
    {
        $this->db->select('*');
        $this->db->from('buku');
        $this->db->join('kategori', 'buku.id_kategori = kategori.id_kategori');
        $this->db->join('pengarang', 'buku.id_pengarang = pengarang.id_pengarang');
        $this->db->join('penerbit', 'buku.id_penerbit = penerbit.id_penerbit');
        $this->db->where('buku.id_buku', $id_buku);
        return $this->db->get()->row_array();
    }

    public function updateData($id_buku, $data)
    {
        $this->db->where('id_buku', $id_buku);
        $this->db->update('buku', $data);
    }

    public function deleteData($id_buku)
    {
        $this->db->where('id_buku', $id_buku);
        $this->db->delete('buku');

    }


    public function getKategori(){
        return $this->db->get('kategori')->result();
    }
    public function getPengarang(){
        return $this->db->get('pengarang')->result();
    }

    public function getPenerbit(){
        return $this->db->get('penerbit')->result();
    }
}