<?php

class M_penerbit extends CI_Model{
    public function getAllData(){
        return $this->db->get('penerbit')->result();
    }

    public function getData($id_penerbit)
    {
        $this->db->where('id_penerbit', $id_penerbit);
        return $this->db->get('penerbit')->row_array();
    }

    public function updateData($id_penerbit, $data)
    {
        $this->db->where('id_penerbit', $id_penerbit);
        $this->db->update('penerbit', $data);
    }

    public function addData($data){
        //masukkan data sesuai inputan pada form
        $this->db->insert('penerbit', $data);
    }

    public function deleteData($id_penerbit)
    {
        $this->db->where('id_penerbit', $id_penerbit);
        $this->db->delete('penerbit');

    }
}