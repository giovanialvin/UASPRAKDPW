<?php

class m_peminjaman extends CI_Model{
    public function getKode_peminjaman()
    {
   
        //ambil 3 karakter  id sebelah kanan  dari database sebagai kode
        $this->db->select('RIGHT(kode_peminjaman,3) as kode', FALSE);
        //urutkan menurut id secara menurun
        $this->db->order_by('kode_peminjaman', 'DESC');
        //ambil 1 record saja
        $this->db->limit(1);
        //sebutkan nama tabel
        $query = $this->db->get('peminjaman');

        /*
        SELECT * FROM peminjaman as kode ORDER BY id LIMIT 1
        */

        //jika terdapat record pada variabel query
        if($query->num_rows() > 0){
            //tampung record tersebut
            $data = $query->row();
            //masukan ke variabel dan ditambah 1
            $kode = intval($data->kode)+1;
        }else{
            //jika tidak ada record pada tabel peminjaman, maka kode bernilai 1
            $kode = 1;
        }
        //gabungkan kode 
        $kodemax = str_pad($kode, 3, "0", STR_PAD_LEFT);
        $finalkode = "PJ".$kodemax;

        //kembalikan kode final
        return $finalkode;
    
    }

    public function getAnggota(){
        return $this->db->get('anggota')->result();
    }

    public function getBuku(){
        return $this->db->get('buku')->result();
    }

    public function addData($data){
        //masukkan data sesuai inputan pada form
        $this->db->insert('peminjaman', $data);
    }

    public function getAllData()
    {
        $this->db->select('*');
        $this->db->from('peminjaman');
        $this->db->join('anggota', 'peminjaman.id_anggota = anggota.id');
        $this->db->join('buku', 'peminjaman.id_buku = buku.id_buku');
        return $this->db->get();
    }

    
    public function getData($id_peminjaman)
    {
        $this->db->select('*');
        $this->db->from('peminjaman');
        $this->db->join('anggota', 'peminjaman.id_anggota = anggota.id');
        $this->db->join('buku', 'peminjaman.id_buku = buku.id_buku');
        $this->db->where('peminjaman.id_peminjaman', $id_peminjaman);
        return $this->db->get()->row_array();
    }

    public function delete($id_peminjaman)
    {
        $this->db->where('id_peminjaman',$id_peminjaman );
        $this->db->delete('peminjaman');
    }

    public function pengembalianBuku($kembalikan)
    {
        $this->db->insert('pengembalian', $kembalikan);
    }

}