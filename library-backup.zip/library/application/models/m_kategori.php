<?php

class M_kategori extends CI_Model{
    public function getAllData(){
        return $this->db->get('kategori')->result();
    }

    public function getData($id_kategori)
    {
        $this->db->where('id_kategori', $id_kategori);
        return $this->db->get('kategori')->row_array();
    }

    public function updateData($id_kategori, $data)
    {
        $this->db->where('id_kategori', $id_kategori);
        $this->db->update('kategori', $data);
    }

    public function addData($data){
        //masukkan data sesuai inputan pada form
        $this->db->insert('kategori', $data);
    }

    public function deleteData($id_kategori)
    {
        $this->db->where('id_kategori', $id_kategori);
        $this->db->delete('kategori');

    }
}